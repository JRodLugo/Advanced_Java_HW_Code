/*
 * Jayden Rodriguez Lugo
 * 07/12/2025
 */
package cop2805;

/**
 * client that connects to the server sending data that the user inputed into the GUI to the server
 * receive fibonacci code from the server
 */

import java.io.IOException;
import java.net.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;

public class Client extends JFrame {
    public JTextField tField; //text field, user input
    public JLabel outField; //JLabel, user output
    //constructor
    public Client(){
        super();
        init();
    }
    //the GUI
    private void init(){
        //setting up Jframe
        JFrame.setDefaultLookAndFeelDecorated(true);
        JFrame frame = new JFrame("Final Project Client");// frame itself
        JLabel label = new JLabel("Enter Fibonacci Number");//label
        JPanel panel = new JPanel();// pannel
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tField = new JTextField(); // text field
        outField = new JLabel("Server Answer: ");
        
        JButton calcBtn = new JButton("Calculate");
        calcBtn.addActionListener(new myButtonListener(this));
        frame.setLayout(new GridLayout(1,15));
        panel.setLayout(new GridLayout(2,1));
        //adding to the pannel and frame
        panel.add(label);
        panel.add(tField);
        panel.add(calcBtn);
        panel.add(outField);
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }
    
    //constructs the GUI
    private static void constructGUI(){
        Client GUI = new Client();
    }
    
    public static void main(String[] args) {
        //runs the GUI
        SwingUtilities.invokeLater(new Runnable(){ 
            public void run(){ constructGUI();}});

    }//end of main
    
    //class that connects to the server to get the sequence
   class myButtonListener implements ActionListener{
        //implements the client into the listener
        private Client client;
       
       //constructor 
       public myButtonListener(Client client){
           this.client = client;
       }
       
        public void actionPerformed(ActionEvent eventData){
            try{
                Socket socket = new Socket("127.0.0.1", 1236);//IP address and the port number
                //once the client connects with the server
                PrintWriter pr = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));//gets outputstream and ties it to a writer
                pr.println(tField.getText());//gets user input
                pr.flush();//this causes what is in println to go out on the network
                BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream())); //gets inputstream and ties it to a bufferedreader
                String response = br.readLine();
                this.client.outField.setText(response);//adds the imput to the GUI
                System.out.println(response);

                //closes socket
                socket.close();
            }catch(UnknownHostException e){
                //this means it couldn't find the IP Address           
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    } 
   

}//end of code

