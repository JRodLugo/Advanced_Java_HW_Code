/*
 * Jayden Rodriguez Lugo
 * 07/12/2025
 */

package cop2805;

/**
 * server that takes generates the fibonacci code based on client input
 * if user enters negative number or letter server responds with error
 */

//librarys
import java.io.IOException;
import java.net.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;

public class Server {

    public static void main(String[] args) {
        boolean shutdown = false; // allows the server to run forever or until its shut down
        //try catch for server socket
        try{
            ServerSocket server = new ServerSocket(1236);//this is the port number
            //loops forever until shutdown becomes true
            while(!shutdown){
                System.out.println("Waiting for Clients....");
                Socket client = server.accept();//causes the server socket to wait until sombody comes in
                //code here runs when sombody connects
                BufferedReader br =  new BufferedReader(new InputStreamReader(client.getInputStream())); //turns user input into a buffered reader
                String input = br.readLine(); // this waits until the client says somthing
                System.out.println("Client said: " + input);
                PrintWriter pr = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));//turns user output into a printwriter
                //if commanded to shutdown
                if(input.contains("shutdown")){
                    shutdown = true; 
                    pr.println("Shutting Down....");
                    pr.flush();
                    break;
                }
                //try catch incase client enters an incompatible answer
                try{
                    int answer = fibonacci(Integer.parseInt(input));
                    if(answer <= 0){//if client enters a negative numbers
                        pr.println("Error: Please enter a positive number");
                        pr.flush();
                    }else{
                        pr.println("Server Answer: " + String.valueOf(answer));//converts the input into a int and the sequence into a string
                        pr.flush();//talks back to the client
                    }
                 //incase client enters a letter or word
                }catch(NumberFormatException e){
                    pr.println("Error: Please enter a positive number");
                    pr.flush();
                    e.printStackTrace();
                }
            }
            //closes server
            System.out.println("we where commanded to shut down");
            server.close();
        }catch(IOException e){
            e.printStackTrace();
        } 
      }//end of main
    //code to calc fibonacci sequence
    public static int fibonacci(int n){
        //int varibles
        int v1 = 0;
        int v2 = 1;
        int v3 = 0;
        //loops the generates the sequence
        for(int i = 2; i <= n; i++){
            v3 = v1+v2;
            v1=v2;
            v2=v3;
        }
        return v3;//returns the answer
    }
     
    }

